package school;

public class Teacher extends Entity{
	public Teacher(String name) {
		super(name);
	}
}




