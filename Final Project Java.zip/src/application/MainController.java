package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import school.*;
import school.Course.*;

import school.*;
import courses.*;
	
public class MainController implements Initializable {
	ArrayList<Course> courses = new ArrayList<Course>();
	
	String newTeacherCourse;
	String newStudentCourse;
	@FXML
	private TextField teacherName;
	
	@FXML
	private TextField studentName;
	@FXML
	public ComboBox<String> studentCourseComboBox;
	
	@FXML
	public ComboBox<String> teacherCourseComboBox;
	
	@FXML
	public  ListView<String> studentListView;
	
	@FXML
	public ListView<String> teacherListView;
	
	ObservableList<String> listStudentCourse = FXCollections.observableArrayList("Network","APIDesign","swing","performance");
	
	ObservableList<String> listStudentAndCourse = FXCollections.observableArrayList("Paul-Network","Hanna-APIDesign","Phil-swing","Onesmus-performance");
	
	ObservableList<String> listTeacherAndCourse = FXCollections.observableArrayList("Bill-Network","James-APIDesign","Peter-swing","Ryanperformance");
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		studentCourseComboBox.setItems(listStudentCourse);
		teacherCourseComboBox.setItems(listStudentCourse);
		studentListView.setItems(listStudentAndCourse);
		teacherListView.setItems(listTeacherAndCourse);
	};
	
	public void addTeacher(ActionEvent event) {
		System.out.println(teacherName.getText());
		Teacher newTeacher = new Teacher(teacherName.getText());
		
		
		listTeacher(event);
		
	}
	
	public void addStudent(ActionEvent event) {
	
		System.out.println(studentName.getText());
		Student newStudent = new Student(studentName.getText());
		
		listStudent(event);
	}
	
	public void listTeacher(ActionEvent event) {
		
		
	};
	public void listStudent(ActionEvent event) {
		
	};
	
	public void comboTeacherChange(ActionEvent event) {
		newTeacherCourse = teacherCourseComboBox.getValue();
		
	}
	public void comboStudentChange(ActionEvent event) {
		newStudentCourse = studentCourseComboBox.getValue();
	}
}
